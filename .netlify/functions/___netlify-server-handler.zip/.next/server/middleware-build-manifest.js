globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/DKruQRy4PdCzEcX99BCPs/_buildManifest.js",
    "static/DKruQRy4PdCzEcX99BCPs/_ssgManifest.js",
    "static/DKruQRy4PdCzEcX99BCPs/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0hlda1~upve6~.js",
    "static/chunks/0dgq26a5_oy.a.js",
    "static/chunks/0n~dq4kpx9xxx.js",
    "static/chunks/0257pdz1-imal.js",
    "static/chunks/turbopack-0he-mzmof.kw~.js"
  ]
};
