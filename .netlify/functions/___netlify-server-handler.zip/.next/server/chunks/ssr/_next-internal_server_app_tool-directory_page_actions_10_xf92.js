module.exports=[59142,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tool-directory_page_actions_10_xf92.js.map