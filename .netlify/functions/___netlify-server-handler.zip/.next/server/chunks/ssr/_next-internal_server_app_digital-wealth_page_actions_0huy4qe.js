module.exports=[7425,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_digital-wealth_page_actions_0huy4qe.js.map