module.exports=[80261,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_make-money-online_page_actions_10uweu9.js.map