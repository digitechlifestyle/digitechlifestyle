module.exports=[91448,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_smart-lifestyle_page_actions_0d4604..js.map